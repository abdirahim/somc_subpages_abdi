somc_subpages_abdi
==================

Displays all subpages of the page it is placed on
